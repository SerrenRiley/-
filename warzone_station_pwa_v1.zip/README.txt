【战区站点 PWA 离线版】使用说明

这是“用网址打开 + 首次加载后可离线玩”的版本（PWA）。

A. Netlify Drop（最快）
1) 用电脑搜索并打开 Netlify Drop
2) 把本文件夹内的 3 个文件：index.html / sw.js / manifest.webmanifest 拖进去上传
3) 它会生成一个 https://xxxx.netlify.app 的网址
4) 用 iPhone Safari 打开该网址 → 分享 → 添加到主屏幕
5) 之后像 App 一样打开；只要成功打开过一次，断网也能玩（离线缓存）

B. GitHub Pages（长期维护）
1) 新建一个 GitHub Public 仓库
2) 上传这 3 个文件到仓库根目录
3) Settings → Pages → Deploy from branch → main / root
4) 得到网址后同样“添加到主屏幕”即可离线

想自己加对话：游戏里右上角“剧情编辑”即可，本地保存，不上传。
